import 'package:delivery_app/dialogs/rd_print_save_package.dart';
import 'package:delivery_app/firestore/enums/e_packages_status.dart';
import 'package:delivery_app/firestore/models/m_package.dart';
import 'package:delivery_app/tools/default_colors.dart';
import 'package:delivery_app/views/user_views/package_details_page.dart';
import 'package:flutter/material.dart';

class PackageItemCard extends StatelessWidget {
  final PackageModel package;

  const PackageItemCard({super.key, required this.package});

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 700;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      elevation: 6,
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: isMobile ? _buildMobile(context) : _buildDesktop(context),
      ),
    );
  }

  // ---------------- DESKTOP ----------------
  Widget _buildDesktop(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: _buildInfo(desktop: true)),
        _divider(),
        _buildActions(context),
      ],
    );
  }

  // ---------------- MOBILE ----------------
  Widget _buildMobile(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildInfo(desktop: false),

        const SizedBox(height: 15),
        const Divider(height: 1),

        // 🔵 FULL BOTTOM FOOTER
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // STATUS + PRICE
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),

                _buildStatusBadge(package.status),
                const SizedBox(height: 6),
                Text(
                  "${package.amount} TND",
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: DefaultColors.primary,
                  ),
                ),
              ],
            ),

            // ACTIONS (right side)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                IconButton(
                  tooltip: "Imprimer",
                  onPressed: () => RdPrintSavePackage.show(context, package),
                  icon: const Icon(Icons.print_outlined, size: 30),
                ),
                IconButton(
                  tooltip: "Détails",
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PackageDetailsPage(package: package),
                    ),
                  ),
                  icon: const Icon(Icons.visibility_outlined, size: 30),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  // ---------------- INFO ----------------
  Widget _buildInfo({required bool desktop}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                "${package.firstName} ${package.lastName}",
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            if (desktop) _buildStatusBadge(package.status),
          ],
        ),

        const SizedBox(height: 6),

        Row(
          children: [
            const Icon(
              Icons.location_on_outlined,
              size: 14,
              color: Colors.grey,
            ),
            const SizedBox(width: 4),
            Expanded(
              child: Text(
                package.governorate.name,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 14),
              ),
            ),
            if (desktop)
              Text(
                "${package.amount} TND",
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: DefaultColors.primary,
                ),
              ),
          ],
        ),

        const SizedBox(height: 4),

        Row(
          children: [
            const Icon(Icons.phone_outlined, size: 14, color: Colors.grey),
            const SizedBox(width: 4),
            Expanded(
              child: Text(
                "${package.phone1}${package.phone2 != null ? ' / ${package.phone2}' : ''}",
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 14),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ---------------- ACTIONS (DESKTOP) ----------------
  Widget _buildActions(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        IconButton(
          tooltip: "Imprimer",
          onPressed: () => RdPrintSavePackage.show(context, package),
          icon: const Icon(Icons.print_outlined, size: 30),
        ),
        const SizedBox(height: 4),
        IconButton(
          tooltip: "Détails",
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PackageDetailsPage(package: package),
            ),
          ),
          icon: const Icon(Icons.visibility_outlined, size: 30),
        ),
      ],
    );
  }

  Widget _divider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Container(width: 1, height: 60, color: Colors.grey.shade300),
    );
  }

  Widget _buildStatusBadge(EPackageStatus status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: DefaultColors.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        status.label.toUpperCase(),
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
          color: DefaultColors.primary,
        ),
      ),
    );
  }
}
